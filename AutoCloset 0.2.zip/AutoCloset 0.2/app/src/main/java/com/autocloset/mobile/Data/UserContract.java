package com.autocloset.mobile.Data;

import android.provider.BaseColumns;

public class UserContract {

    public class UserEntry implements BaseColumns {

        public static final String TABLE_NAME = "user";

        public static final String USER_ID = "userID";
    }
}
