package com.autocloset.mobile;

public class ClothingAdapter {
}
